/////////////////////////////////////KIWISEC///////////////////////////////////
//                                                                           //
// KIWISEC SDK HEADER FILE FOR APPLE XCODE IOS PROJECT                       //
//                                                                           //
// Copyright(C) 2014-2015 成都盈海益讯科技有限公司, ALL RIGHTS RESERVED.         //
//                                                                           //
// Internet: http://www.kiwisec.com/                                         //
//                                                                           //
// IMPORTANT NOTE:                                                           //
// TO ENSURE YOUR APP's SECURITY, DO NOT LEAK THIS SDK HEADER FILE TO ANYONE!//
//                                                                           //
// This code is distributed "as is", part of KIWISEC and without warranty of //
// any kind, expressed or implied, including, but not limited to warranty of //
// fitness for any particular purpose. In no event will KIWISEC be liable to //
// you for any special, incidental, indirect, consequential or any other     //
// damages caused by the use, misuse, or the inability to use of this code,  //
// including anylost profits or lost savings,even if KIWISEC has been advised//
// of the possibility of such damages.                                       //
//                                                                           //
///////////////////////////////////////*///////////////////////////////////////
#ifndef kiwisec_KiwiCryptor_h
#define kiwisec_KiwiCryptor_h

#import <Foundation/Foundation.h>

#include "KiwiBase.h"
#include "KiwiError.h"
#include "iKiwiRandomName.h"

#define __KIWI_ENCMODE_STRING_XOR__ "xor"
#define __KIWI_ENCMODE_XOR__ 0
#define __KIWI_ENCMODE_STRING_AES256__ "AES256"
#define __KIWI_ENCMODE_AES256__ 1
#define __KIWI_ENCMODE_STRING_DES__ "DES"
#define __KIWI_ENCMODE_DES__ 2
#define __KIWI_ENCMODE_STRING_DES3__ "DES3"
#define __KIWI_ENCMODE_DES3__ 3
#define __KIWI_ENCMODE_STRING_BASE64__ "BASE64"
#define __KIWI_ENCMODE_BASE64__ 4
#define __KIWI_ENCMODE_STRING_BLOWFISH__ "BLOWFISH"
#define __KIWI_ENCMODE_BLOWFISH__ 5

@interface KiwiCryptor : NSObject

/*
 @name：encrypt:key:mode:
 @func：加解密NSData数据
 @var0：src－需要加/解密的数据
 @var1：k－加密英子
 @var2：m－加密类型，即__KIWI_ENCMODE_＊__
 */
+(NSData *)encrypt:(NSData *)src key:(NSString *)k mode:(int)m;
+(NSData *)decrypt:(NSData *)src key:(NSString *)k mode:(int)m;

/*
 @name：str_encrypt:key:mode:
 @func：加解密NSString数据
 @var0：src－需要加/解密的数据
 @var1：k－加密因子
 @var2：m－加密类型，即__KIWI_ENCMODE_＊__
 */
+(NSString *)str_encrypt:(NSString *)src key:(NSString *)k mode:(int)m;
+(NSString *)str_decrypt:(NSString *)src key:(NSString *)k mode:(int)m;

@end

#endif // end of kiwisec_KiwiCryptor_h
