/////////////////////////////////////KIWISEC///////////////////////////////////
//                                                                           //
// KIWISEC SDK HEADER FILE FOR APPLE XCODE IOS PROJECT                       //
//                                                                           //
// Copyright(C) 2014-2015 成都盈海益讯科技有限公司, ALL RIGHTS RESERVED.         //
//                                                                           //
// Internet: http://www.kiwisec.com/                                         //
//                                                                           //
// IMPORTANT NOTE:                                                           //
// TO ENSURE YOUR APP's SECURITY, DO NOT LEAK THIS SDK HEADER FILE TO ANYONE!//
//                                                                           //
// This code is distributed "as is", part of KIWISEC and without warranty of //
// any kind, expressed or implied, including, but not limited to warranty of //
// fitness for any particular purpose. In no event will KIWISEC be liable to //
// you for any special, incidental, indirect, consequential or any other     //
// damages caused by the use, misuse, or the inability to use of this code,  //
// including anylost profits or lost savings,even if KIWISEC has been advised//
// of the possibility of such damages.                                       //
//                                                                           //
///////////////////////////////////////*///////////////////////////////////////

#ifndef kiwisec_KiwiCallback_h
#define kiwisec_KiwiCallback_h

#include "KiwiBase.h"
#include "KiwiError.h"
#include "iKiwiRandomName.h"

//info is type of KiwiSendInfo
typedef void (* KiwiCallback_t)(void *info);

//When check hits, then call the following callbacks
struct KiwiCheckCallbacks {
    KiwiCallback_t debugger; // detect a debugger
    KiwiCallback_t jailbreak;// detect jailbreak runtime
    KiwiCallback_t injecter; // detect a dylib injecter
    KiwiCallback_t hooker;   // detect a system API or objc method hooker
    KiwiCallback_t tamper;   // detect tamper for our code
};

//Fill it in target project
extern struct KiwiCheckCallbacks theCheckCallbacks;

#ifdef __cplusplus
extern "C" {
#endif // end of __cplusplus
    /*
     @name：SetTickTime
     @func：设置检测时间间隔
     @var0：tick－设置时间间隔，为正数
     */
    enum KiwiErrorCode  KiwiSetTickTime(int tick);
    
    /*
     @name：KiwiCheckHooker
     @func：获取检测时间间隔
     @var0：tick－返回时间间隔
     */
    enum KiwiErrorCode KiwiGetTickTime(int *tick);
    
    //internal use!
    void KiwiProcessCallbacks(KiwiCallback_t debug,KiwiCallback_t hook,KiwiCallback_t checksum,
                              KiwiCallback_t inject,KiwiCallback_t jailbreak);
    
#ifdef __cplusplus
}
#endif // end of __cplusplus

#endif
