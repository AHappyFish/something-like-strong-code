/////////////////////////////////////KIWISEC///////////////////////////////////
//                                                                           //
// KIWISEC SDK HEADER FILE FOR APPLE XCODE IOS PROJECT                       //
//                                                                           //
// Copyright(C) 2014-2015 成都盈海益讯科技有限公司, ALL RIGHTS RESERVED.         //
//                                                                           //
// Internet: http://www.kiwisec.com/                                         //
//                                                                           //
// IMPORTANT NOTE:                                                           //
// TO ENSURE YOUR APP's SECURITY, DO NOT LEAK THIS SDK HEADER FILE TO ANYONE!//
//                                                                           //
// This code is distributed "as is", part of KIWISEC and without warranty of //
// any kind, expressed or implied, including, but not limited to warranty of //
// fitness for any particular purpose. In no event will KIWISEC be liable to //
// you for any special, incidental, indirect, consequential or any other     //
// damages caused by the use, misuse, or the inability to use of this code,  //
// including anylost profits or lost savings,even if KIWISEC has been advised//
// of the possibility of such damages.                                       //
//                                                                           //
///////////////////////////////////////*///////////////////////////////////////

#ifndef kiwisec_KiwiAppString_h
#define kiwisec_KiwiAppString_h

#include "iKiwiRandomName.h"

#define KIWI_ENCODE_XOR 0

#ifdef __cplusplus
extern "C" {
#endif // end of __cplusplus
    
    typedef struct _KiwiEncodedString {
        char *ptr;  //buffer pointer
        int size;   //buffer size
        int decoded;//already decoded?
        int type;   //type
    }KiwiEncodedString;
    
    //internal use!
    char *KiwiDecodeCString(KiwiEncodedString *data);
    
#ifdef __OBJC__

#import <Foundation/Foundation.h>
    
    NSString *KiwiDecodeOcString(KiwiEncodedString *data);
    
#endif // end of __OBJC__

#ifdef __cplusplus
}
#endif // end of __cplusplus

#endif // end of kiwisec_KiwiAppString_h
