/////////////////////////////////////KIWISEC///////////////////////////////////
//                                                                           //
// KIWISEC SDK HEADER FILE FOR APPLE XCODE IOS PROJECT                       //
//                                                                           //
// Copyright(C) 2014-2015 成都盈海益讯科技有限公司, ALL RIGHTS RESERVED.         //
//                                                                           //
// Internet: http://www.kiwisec.com/                                         //
//                                                                           //
// IMPORTANT NOTE:                                                           //
// TO ENSURE YOUR APP's SECURITY, DO NOT LEAK THIS SDK HEADER FILE TO ANYONE!//
//                                                                           //
// This code is distributed "as is", part of KIWISEC and without warranty of //
// any kind, expressed or implied, including, but not limited to warranty of //
// fitness for any particular purpose. In no event will KIWISEC be liable to //
// you for any special, incidental, indirect, consequential or any other     //
// damages caused by the use, misuse, or the inability to use of this code,  //
// including anylost profits or lost savings,even if KIWISEC has been advised//
// of the possibility of such damages.                                       //
//                                                                           //
///////////////////////////////////////*///////////////////////////////////////

#ifndef kiwisec_KiwiSecurity_h
#define kiwisec_KiwiSecurity_h

#include "KiwiAntiHook.h"
#include "KiwiAntiTamper.h"
#include "KiwiAntiDebug.h"
#include "KiwiAntiJailbreak.h"
#include "KiwiAntiInject.h"
#include "KiwiCallback.h"
#include "KiwiCheckSum.h"
#include "KiwiCallbackList.h"

#if __i386__ || __x86_64__
//internal use
//currently, we only support iphoneos!
#include "KiwiAppStringIntel.h"
#else
#include "KiwiAppString.h"
#endif // end of __i386__ || __x86_64__

#include "KiwiCodeExpand.h"

#ifdef __OBJC__
#import "KiwiCryptor.h"
#import "KiwiReflect.h"
#endif // end of __OBJC__

#endif // end of kiwisec_KiwiSecurity_h
