/////////////////////////////////////KIWISEC///////////////////////////////////
//                                                                           //
// KIWISEC SDK HEADER FILE FOR APPLE XCODE IOS PROJECT                       //
//                                                                           //
// Copyright(C) 2014-2015 成都盈海益讯科技有限公司, ALL RIGHTS RESERVED.         //
//                                                                           //
// Internet: http://www.kiwisec.com/                                         //
//                                                                           //
// IMPORTANT NOTE:                                                           //
// TO ENSURE YOUR APP's SECURITY, DO NOT LEAK THIS SDK HEADER FILE TO ANYONE!//
//                                                                           //
// This code is distributed "as is", part of KIWISEC and without warranty of //
// any kind, expressed or implied, including, but not limited to warranty of //
// fitness for any particular purpose. In no event will KIWISEC be liable to //
// you for any special, incidental, indirect, consequential or any other     //
// damages caused by the use, misuse, or the inability to use of this code,  //
// including anylost profits or lost savings,even if KIWISEC has been advised//
// of the possibility of such damages.                                       //
//                                                                           //
///////////////////////////////////////*///////////////////////////////////////

#ifndef kiwisec_KiwiAntiTamper_h
#define kiwisec_KiwiAntiTamper_h

#include "KiwiBase.h"
#include "KiwiError.h"
#include "iKiwiRandomName.h"

#ifdef __cplusplus
extern "C" {
#endif // end of __cplusplus
    
    /*
     @name：KiwiCheckTamper
     @func：检测ptrace系统调用是否被更改
     @var0：tamped－1表示被更改，0表示未被更改
     */
    __KIWI_API_STATIC__
    enum KiwiErrorCode KiwiCheckTamper(KiwiBool *tamped);
    
    /*
     @name：KiwiCheckTamper1
     @func：检测ptrace系统调用是否被更改，因为有可能ptrace调用会被完全修改，所以针对指定函数进行前面条指令进行校验
     @var0：tamped－1表示被更改，0表示未被更改
     */
    __KIWI_API_STATIC__
    enum KiwiErrorCode KiwiCheckTamper1(KiwiBool *tamped);
    
    
    /*
     @name：KiwiCheckTamper2
     @func：检测ptrace系统调用是否被更改
     @var0：tamped－1表示被更改，0表示未被更改
     */
    __KIWI_API_STATIC__
    enum KiwiErrorCode KiwiCheckTamper2(KiwiBool *tamped);
    
    
    /*
     @name：KiwiCheckTamper3
     @func：检测ptrace系统调用是否被更改
     @var0：tamped－1表示被更改，0表示未被更改
     */
    __KIWI_API_STATIC__
    enum KiwiErrorCode KiwiCheckTamper3(KiwiBool *tamped);
    
#ifdef __cplusplus
}
#endif // end of __cplusplus

#endif
