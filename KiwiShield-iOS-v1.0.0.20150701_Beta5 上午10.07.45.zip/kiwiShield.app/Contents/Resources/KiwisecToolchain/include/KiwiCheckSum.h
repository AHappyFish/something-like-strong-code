/////////////////////////////////////KIWISEC///////////////////////////////////
//                                                                           //
// KIWISEC SDK HEADER FILE FOR APPLE XCODE IOS PROJECT                       //
//                                                                           //
// Copyright(C) 2014-2015 成都盈海益讯科技有限公司, ALL RIGHTS RESERVED.         //
//                                                                           //
// Internet: http://www.kiwisec.com/                                         //
//                                                                           //
// IMPORTANT NOTE:                                                           //
// TO ENSURE YOUR APP's SECURITY, DO NOT LEAK THIS SDK HEADER FILE TO ANYONE!//
//                                                                           //
// This code is distributed "as is", part of KIWISEC and without warranty of //
// any kind, expressed or implied, including, but not limited to warranty of //
// fitness for any particular purpose. In no event will KIWISEC be liable to //
// you for any special, incidental, indirect, consequential or any other     //
// damages caused by the use, misuse, or the inability to use of this code,  //
// including anylost profits or lost savings,even if KIWISEC has been advised//
// of the possibility of such damages.                                       //
//                                                                           //
///////////////////////////////////////*///////////////////////////////////////

#ifndef __kiwisec__KiwiCheckSum__
#define __kiwisec__KiwiCheckSum__

#include <stdio.h>

#include "iKiwiRandomName.h"

#define __KIWI_CKSMODE_STRING_MD5__ "MD5"
#define __KIWI_CKSMODE_MD5__ 0
#define __KIWI_CKSMODE_STRING_MD5FILE__ "MD5FILE"
#define __KIWI_CKSMODE_MD5FILE__ 1
#define __KIWI_CKSMODE_STRING_CRC32__ "CRC32"
#define __KIWI_CKSMODE_CRC32__ 2

#ifdef __cplusplus
extern "C" {
#endif // end of __cplusplus
    
    /*
     @name：KiwiCheckSum
     @func：校验和计算函数
     @var0：pData 指向需要计算校验和的数据，如果是MD5FILE，表示文件路径
     @var1: nDatalen 数据长度，如果是MD5FILE，为路径的长度
     @var2: m 计算方式
     @var3: output MD5&MD5FILE的返回值
     @return CRC32返回crc32值
     */
    
    unsigned long KiwiCheckSum(void *pData, int nDatalen, int m, unsigned char output[16]);
    
#ifdef __cplusplus
}
#endif // end of __cplusplus

#endif /* defined(__kiwisec__KiwiCheckSum__) */
