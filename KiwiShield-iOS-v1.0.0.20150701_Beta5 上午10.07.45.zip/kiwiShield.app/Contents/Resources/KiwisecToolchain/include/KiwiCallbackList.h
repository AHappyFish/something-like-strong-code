/////////////////////////////////////KIWISEC///////////////////////////////////
//                                                                           //
// KIWISEC SDK HEADER FILE FOR APPLE XCODE IOS PROJECT                       //
//                                                                           //
// Copyright(C) 2014-2015 成都盈海益讯科技有限公司, ALL RIGHTS RESERVED.         //
//                                                                           //
// Internet: http://www.kiwisec.com/                                         //
//                                                                           //
// IMPORTANT NOTE:                                                           //
// TO ENSURE YOUR APP's SECURITY, DO NOT LEAK THIS SDK HEADER FILE TO ANYONE!//
//                                                                           //
// This code is distributed "as is", part of KIWISEC and without warranty of //
// any kind, expressed or implied, including, but not limited to warranty of //
// fitness for any particular purpose. In no event will KIWISEC be liable to //
// you for any special, incidental, indirect, consequential or any other     //
// damages caused by the use, misuse, or the inability to use of this code,  //
// including anylost profits or lost savings,even if KIWISEC has been advised//
// of the possibility of such damages.                                       //
//                                                                           //
///////////////////////////////////////*///////////////////////////////////////

#ifndef __kiwisec__KiwiCallbackList__
#define __kiwisec__KiwiCallbackList__

#include "iKiwiRandomName.h"

#ifdef __cplusplus
extern "C" {
#endif // end of __cplusplus
    
    //The below interfaces are used automatically!
    
    void KiwiUploadAttackJailbreak(void *info);
    void KiwiUploadAttackInject(void *info);
    void KiwiUploadAttackDebug(void *info);
    void KiwiUploadAttackChecksum(void *info);
    void KiwiUploadAttackHook(void *info);
    
    void KiwiUploadAttackJailbreakAndExit(void *info);
    void KiwiUploadAttackInjectAndExit(void *info);
    void KiwiUploadAttackDebugAndExit(void *info);
    void KiwiUploadAttackChecksumAndExit(void *info);
    void KiwiUploadAttackHookAndExit(void *info);
    
    int KiwiDetectAttack0(void *p);
    int KiwiDetectAttack1(void *p);
    int KiwiDetectAttack2(void *p);
    int KiwiDetectAttack3(void *p);
    int KiwiDetectAttack4(void *p);
    int KiwiDetectAttack5(void *p);
    int KiwiDetectAttack6(void *p);
    int KiwiDetectAttack7(void *p);
    int KiwiDetectAttack8(void *p);
    int KiwiDetectAttack9(void *p);
    int KiwiDetectAttack10(void *p);
    int KiwiDetectAttack11(void *p);
    int KiwiDetectAttack12(void *p);
    int KiwiDetectAttack13(void *p);
    int KiwiDetectAttack14(void *p);
    int KiwiDetectAttack15(void *p);
    int KiwiDetectAttack16(void *p);
    int KiwiDetectAttack17(void *p);
    int KiwiDetectAttack18(void *p);
    int KiwiDetectAttack19(void *p);
    
#ifdef __cplusplus
}
#endif // end of __cplusplus

#endif /* defined(__kiwisec__KiwiCallbackList__) */
