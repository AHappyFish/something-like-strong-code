/////////////////////////////////////KIWISEC///////////////////////////////////
//                                                                           //
// KIWISEC SDK HEADER FILE FOR APPLE XCODE IOS PROJECT                       //
//                                                                           //
// Copyright(C) 2014-2015 成都盈海益讯科技有限公司, ALL RIGHTS RESERVED.         //
//                                                                           //
// Internet: http://www.kiwisec.com/                                         //
//                                                                           //
// IMPORTANT NOTE:                                                           //
// TO ENSURE YOUR APP's SECURITY, DO NOT LEAK THIS SDK HEADER FILE TO ANYONE!//
//                                                                           //
// This code is distributed "as is", part of KIWISEC and without warranty of //
// any kind, expressed or implied, including, but not limited to warranty of //
// fitness for any particular purpose. In no event will KIWISEC be liable to //
// you for any special, incidental, indirect, consequential or any other     //
// damages caused by the use, misuse, or the inability to use of this code,  //
// including anylost profits or lost savings,even if KIWISEC has been advised//
// of the possibility of such damages.                                       //
//                                                                           //
///////////////////////////////////////*///////////////////////////////////////

//////////////////////////////Random Our API Name//////////////////////////////

#include "KiwiBase.h" 

#if __KIWI_SEC_IS_RELEASE__

#ifndef KiwiAntiDebug
#define KiwiAntiDebug                   /*RPM*/_83A94997_00A3_4664_B91B_48A182145E66
#endif

#ifndef KiwiCheckDebugger0
#define KiwiCheckDebugger0              /*RPM*/_51BAAAF8_86F8_4224_B5AE_AD45E45BF589
#endif

#ifndef KiwiCheckDebugger1
#define KiwiCheckDebugger1              /*RPM*/_CC13265D_EF7B_4105_834A_F30132BE673F
#endif

#ifndef KiwiCheckDebugger2
#define KiwiCheckDebugger2              /*RPM*/_0D630FF5_8086_4329_B4F6_2F0A8288D72A
#endif

#ifndef KiwiCheckDebugger3
#define KiwiCheckDebugger3              /*RPM*/_5DA79027_D047_443E_82BC_F9E9021011BA
#endif

#ifndef KiwiCheckSum
#define KiwiCheckSum                    /*RPM*/_CC7FABC4_FF96_43DC_B969_E1A026537E53
#endif

#ifndef KiwiFileChecker
#define KiwiFileChecker                 /*RPM*/_B0A5CA40_2DBB_4467_9876_50F26318292B
#endif

#ifndef KiwiCheckAllFile
#define KiwiCheckAllFile                /*RPM*/_FDF68613_1BA1_4AFD_BB20_A652679F57A1
#endif

#ifndef KiwiCallbackInit
#define KiwiCallbackInit                /*RPM*/_C01FCDF9_7EE7_4084_93EC_FCE7A0EA9757
#endif

#ifndef KiwiCallbackUninit
#define KiwiCallbackUninit              /*RPM*/_5F4B6631_A280_46C3_A546_67BD89EE49D7
#endif

#ifndef KiwiCheckHooker
#define KiwiCheckHooker                 /*RPM*/_4A688E81_E07F_46F0_A35F_787376CD35E3
#endif

#ifndef KiwiAntiHookInit
#define KiwiAntiHookInit                /*RPM*/_CC05C344_00FC_49D8_92B8_25BE7933C0F0
#endif

#ifndef KiwiCheckTamper
#define KiwiCheckTamper                 /*RPM*/_7E5F7871_1D67_41A7_848D_6099250A7A8C
#endif

#ifndef KiwiCheckTamper1
#define KiwiCheckTamper1                /*RPM*/_8BB48E62_C15B_42C5_971E_9ECDD7AF99B4
#endif

#ifndef KiwiCheckTamper2
#define KiwiCheckTamper2                /*RPM*/_7217F970_45E0_4B6A_90ED_ECB9030FDB13
#endif

#ifndef KiwiCheckTamper3
#define KiwiCheckTamper3                /*RPM*/_86082BD4_7766_474E_9FDF_B8A10DA92968
#endif

#ifndef KiwiCheckJailbreak
#define KiwiCheckJailbreak              /*RPM*/_0037BAE6_EEBA_4DFE_847E_8767E15B263C
#endif

#ifndef KiwiCheckInjecter0
#define KiwiCheckInjecter0              /*RPM*/_70FBB6AA_5E84_4F70_9FD6_E874058622DB
#endif

#ifndef KiwiCheckInjecter1
#define KiwiCheckInjecter1              /*RPM*/_88ABEDFF_B2E1_45CA_BCC8_3F359DDE077F
#endif

#ifndef KiwiUploadAttackJailbreak
#define KiwiUploadAttackJailbreak       /*RPM*/_3A719779_70CD_4CF4_A597_CF1D6F2A3415
#endif

#ifndef KiwiUploadAttackInject
#define KiwiUploadAttackInject          /*RPM*/_7BD7EBBA_88BC_4A40_A8DF_BD105746C8B6
#endif

#ifndef KiwiUploadAttackDebug
#define KiwiUploadAttackDebug           /*RPM*/_EB284CFF_4BE1_47D0_8B4D_E255858EE39C
#endif

#ifndef KiwiUploadAttackChecksum
#define KiwiUploadAttackChecksum        /*RPM*/_8461E8F5_3B4C_4DF5_A446_DBADA7B6E9A3
#endif

#ifndef KiwiUploadAttackHook
#define KiwiUploadAttackHook            /*RPM*/_2842D987_4DA8_4773_B978_9A27D48C55ED
#endif

#ifndef KiwiUploadAttackJailbreakAndExit
#define KiwiUploadAttackJailbreakAndExit /*RPM*/_2356167B_75EB_4F42_B64A_BC1AFF2F4683
#endif

#ifndef KiwiUploadAttackInjectAndExit
#define KiwiUploadAttackInjectAndExit   /*RPM*/_00A3B630_1BB1_48D4_9C08_E8959DCE56A5
#endif

#ifndef KiwiUploadAttackDebugAndExit
#define KiwiUploadAttackDebugAndExit    /*RPM*/_E48FCC4D_3615_4C2F_932E_C3F377871659
#endif

#ifndef KiwiUploadAttackChecksumAndExit
#define KiwiUploadAttackChecksumAndExit /*RPM*/_E94ED0FE_28DC_423B_BB7E_0184EE1790EF
#endif

#ifndef KiwiUploadAttackHookAndExit
#define KiwiUploadAttackHookAndExit     /*RPM*/_897D9FB8_91B2_488D_B83D_3666923CD53D
#endif

#ifndef KiwiClient
#define KiwiClient                      /*RPM*/_0F76A572_ECC6_484A_9919_39BF56A82AFA
#endif

#ifndef KiwiUploadAttackInfo
#define KiwiUploadAttackInfo            /*RPM*/_C6A98356_0E0D_402F_98D8_23062A65AA92
#endif

#ifndef KiwiUploadDeviceInfo
#define KiwiUploadDeviceInfo            /*RPM*/_2D1487EC_7DB2_4AFA_A650_A8753655ACB8
#endif

#ifndef AddCheckedFunctionForOc
#define AddCheckedFunctionForOc         /*RPM*/_B4FDFDC2_F93E_4413_990E_CC9AD1F977FB
#endif

#ifndef DeletCheckedFunctionForOc
#define DeletCheckedFunctionForOc       /*RPM*/_C657AAFE_925B_4E03_8CF5_731553BDBD5C
#endif

#ifndef AddCheckedFunctionByPtr
#define AddCheckedFunctionByPtr         /*RPM*/_BBD6E6B1_37CE_41DD_8206_7CF3B40C3E2D
#endif

#ifndef DeletCheckedFunctionByPtr
#define DeletCheckedFunctionByPtr       /*RPM*/_8851C361_57FF_4A19_BAA8_FD3A41E1C1DC
#endif

#ifndef AddCheckedFunctionForIat
#define AddCheckedFunctionForIat        /*RPM*/_8632A207_5524_4FCF_8B60_097FCE9FE753
#endif

#ifndef DeletCheckedFunctionForIat
#define DeletCheckedFunctionForIat      /*RPM*/_BE4A63D5_4FE0_446C_9B49_1543E335AAE2
#endif

#ifndef KiwiGetTickTime
#define KiwiGetTickTime                 /*RPM*/_3D0F7BE6_99C7_465E_AFFD_4C9E36E48955
#endif

#ifndef KiwiSetTickTime
#define KiwiSetTickTime                 /*RPM*/_2BBD269E_F717_4AF0_96C5_31F31BB25A98
#endif

#ifndef iKiwiCheckAttackThread
#define iKiwiCheckAttackThread          /*RPM*/_9123FB08_4261_4E70_98A9_5F81BE700ECF
#endif

#ifndef iKiwiCheckAttack
#define iKiwiCheckAttack                /*RPM*/_1056BC97_64D2_44D2_9839_FF8A7350E06D
#endif

#ifndef AntiHookInfo
#define AntiHookInfo                    /*RPM*/_72D57732_A316_4E70_9A22_998190B42BEA
#endif

#ifndef _ANTIHOOKINFO
#define _ANTIHOOKINFO                   /*RPM*/_9527B77E_EEFE_4C52_AA63_DE2BC936A842
#endif

#ifndef AddCheckedFunction
#define AddCheckedFunction              /*RPM*/_87D573B2_AE6F_4883_8B36_7698E8756ADB
#endif

#ifndef DeletCheckedFunction
#define DeletCheckedFunction            /*RPM*/_87A75011_A62E_4C52_BD95_549DC6F62159
#endif

#ifndef KIWIAntiHookUnint
#define KIWIAntiHookUnint               /*RPM*/_FE77A56D_B736_43DD_956A_312523505E04
#endif

#ifndef iKiwiMemacho
#define iKiwiMemacho                    /*RPM*/_C4C5D891_8193_4731_BABD_A03D7119E74D
#endif

#ifndef KiwiDetectAttack0
#define KiwiDetectAttack0               /*RPM*/_69EEAD7C_E53D_4FFF_847A_96F6D137DD0A
#endif

#ifndef KiwiDetectAttack1
#define KiwiDetectAttack1               /*RPM*/_3DAF2058_3D18_44EA_BCA0_6322B4AB6D06
#endif

#ifndef KiwiDetectAttack2
#define KiwiDetectAttack2               /*RPM*/_6F86B538_CF3F_4ADD_B0ED_6122222C8E0F
#endif

#ifndef KiwiDetectAttack3
#define KiwiDetectAttack3               /*RPM*/_A6C3FD4F_BF49_4314_A898_189508013461
#endif

#ifndef KiwiDetectAttack4
#define KiwiDetectAttack4               /*RPM*/_ACEBDFF6_78C1_4D20_B434_7757EA697199
#endif

#ifndef KiwiDetectAttack5
#define KiwiDetectAttack5               /*RPM*/_C685985E_7EA6_45DE_8E84_4087941DE18E
#endif

#ifndef KiwiDetectAttack6
#define KiwiDetectAttack6               /*RPM*/_30BA7505_BDC1_4DA7_9641_1298BA2D378C
#endif

#ifndef KiwiDetectAttack7
#define KiwiDetectAttack7               /*RPM*/_757A3B23_75E2_486B_8D71_4B10DBA76DB0
#endif

#ifndef KiwiDetectAttack8
#define KiwiDetectAttack8               /*RPM*/_1930279C_0D3E_4F46_A475_ECB073462A34
#endif

#ifndef KiwiDetectAttack9
#define KiwiDetectAttack9               /*RPM*/_ADABB5AE_14B1_46A6_9D52_B1EC163FD1BB
#endif

#ifndef KiwiDetectAttack10
#define KiwiDetectAttack10              /*RPM*/_A7916BC0_436B_4F12_8AEE_C84D714EB846
#endif

#ifndef KiwiDetectAttack11
#define KiwiDetectAttack11              /*RPM*/_D3CBE2B4_A7A4_42EC_B2FE_1AA7411ADE56
#endif

#ifndef KiwiDetectAttack12
#define KiwiDetectAttack12              /*RPM*/_D607E96C_2756_473F_9BAD_61D0E5582D26
#endif

#ifndef KiwiDetectAttack13
#define KiwiDetectAttack13              /*RPM*/_5D130A25_F564_4982_8623_2C50A6FB376D
#endif

#ifndef KiwiDetectAttack14
#define KiwiDetectAttack14              /*RPM*/_F2B3E47E_0379_4436_A91E_EA4F96BAD21E
#endif

#ifndef KiwiDetectAttack15
#define KiwiDetectAttack15              /*RPM*/_124203E6_7773_471D_A95D_ED34239926BE
#endif

#ifndef KiwiDetectAttack16
#define KiwiDetectAttack16              /*RPM*/_F0850F42_D555_40B6_BE9F_EA9ED31B5328
#endif

#ifndef KiwiDetectAttack17
#define KiwiDetectAttack17              /*RPM*/_F620FD98_0F40_45C5_A1B6_F14EF38F80C3
#endif

#ifndef KiwiDetectAttack18
#define KiwiDetectAttack18              /*RPM*/_624C4A3D_26F1_4680_B717_985B1EEDD835
#endif

#ifndef KiwiDetectAttack19
#define KiwiDetectAttack19              /*RPM*/_BEAA463C_97A5_4915_A669_E80BFD34C4F1
#endif

#ifndef KiwiCryptor
#define KiwiCryptor                     /*RPM*/_10986D01_813E_4651_9970_41B85884B7DA
#endif

#ifndef KiwiKeyChain
#define KiwiKeyChain                    /*RPM*/_360B43A9_2AC5_42D3_86C9_90F8854D45C4
#endif

#ifndef KiwiTransDataToS
#define KiwiTransDataToS                /*RPM*/_24505049_05F5_483B_83E1_87404B3D68D3
#endif

#ifndef KiwiTamperInit
#define KiwiTamperInit                  /*RPM*/_1AC7F8B4_2597_4FEB_AD59_A3799314ACC9
#endif

#ifndef kiwistrncmp
#define kiwistrncmp                     /*RPM*/_316F6DCD_FF9D_4CF8_B02E_E77C7DCA85D5
#endif

#ifndef iKiwiMemachoTravelState
#define iKiwiMemachoTravelState         /*RPM*/_8CFB9AF2_411C_41A2_A607_179365EDB0D4
#endif

#ifndef KiwiGetInfor
#define KiwiGetInfor                    /*RPM*/_0AD0732A_E056_4EFD_943D_3F0D2781DA21
#endif

#ifndef gKiwiClient
#define gKiwiClient                     /*RPM*/_1730B71A_D48F_493E_ACBB_6684803B8125
#endif

#ifndef kiwi_dladdr
#define kiwi_dladdr                     /*RPM*/_32D7C7C7_0CE1_4819_80CA_00ABC1C6C8C3
#endif

#ifndef kiwi_dlsym
#define kiwi_dlsym                      /*RPM*/_2D2D65C9_2EAB_40CB_B3BB_73FDE26FD4CA
#endif

#ifndef kiwiclass_getClassMethod
#define kiwiclass_getClassMethod        /*RPM*/_EA2C606A_9B42_44FF_93E8_AFBED4D895F1
#endif

#ifndef kiwiclass_getInstanceMethod
#define kiwiclass_getInstanceMethod     /*RPM*/_2A394808_D825_4A37_AD60_E0D1C90897BF
#endif

#ifndef kiwimethod_getImplementation
#define kiwimethod_getImplementation    /*RPM*/_6ACFCB27_B957_441B_9145_04E61E317ADA
#endif

#ifndef kiwiobjc_getClass
#define kiwiobjc_getClass               /*RPM*/_68EC4A00_B833_42B3_8E77_C14BBFE0D1D4
#endif

#ifndef kiwi_get_symbos
#define kiwi_get_symbos                 /*RPM*/_6991B9C2_251F_447C_8EBC_2FEDDCC1AE63
#endif

#ifndef kiwi_get_gLinkContext
#define kiwi_get_gLinkContext           /*RPM*/_E5BD6A3E_AE59_4910_B5F1_1D779E5C6F05
#endif

#ifndef kiwi_getExportedSymbolAddress
#define kiwi_getExportedSymbolAddress   /*RPM*/_4A28D155_4A2A_4985_968F_9B1A1A068F5A
#endif

#ifndef kiwi_hook_type
#define kiwi_hook_type                  /*RPM*/_E880470D_5BDD_4014_BF7E_43741EE480CA
#endif

#ifndef iKiwiInitMainMachO
#define iKiwiInitMainMachO              /*RPM*/_7E4EB6C7_EAFB_4D85_9B92_CD7DC101DC1D
#endif

#ifndef iKiwiAntiTable
#define iKiwiAntiTable                  /*RPM*/_6EF0F9E5_3FBB_4173_9810_E9E0AD611712
#endif

#ifndef DefaultiKiwiAntiTable
#define DefaultiKiwiAntiTable           /*RPM*/_26F1B549_C651_43E2_9778_D67E331D1A2F
#endif

#ifndef kiwi_get_symtab_dyld
#define kiwi_get_symtab_dyld            /*RPM*/_788C2F39_99A4_422C_AF9A_64CB69B63EFC
#endif

#ifndef kiwi_p_gLinkContext
#define kiwi_p_gLinkContext             /*RPM*/_796A0DC9_5DC9_4389_B6B8_EF8402F1F5CC
#endif

#ifndef KiwiSecTransDataType
#define KiwiSecTransDataType            /*RPM*/_F6292427_230A_4053_9DEA_0A2BB8963763
#endif

#ifndef KiwiSetServerIp
#define KiwiSetServerIp                 /*RPM*/_4E225759_1C86_4565_9D7E_07A6FDDA9222
#endif

#ifndef KiwiAttackType
#define KiwiAttackType                  /*RPM*/_1BB5D6E0_BED3_4508_A66B_3666BD7FD2A9
#endif

#ifndef _KiwiAttackType
#define _KiwiAttackType                 /*RPM*/_DAD69DB4_8C32_418B_B185_8E323DE35B39
#endif

#ifndef KiwiClientData
#define KiwiClientData                  /*RPM*/_50A4E8B2_5B51_42CC_AFE5_501147391897
#endif

#ifndef _KiwiClientData
#define _KiwiClientData                 /*RPM*/_2CE1BEBD_ED8E_4CD5_9BD1_5DBE7F54B3C2
#endif

#ifndef KiwiHaveInited
#define KiwiHaveInited                  /*RPM*/_28F21C30_1120_4DEB_886D_D95EEB4BB11A
#endif

#ifndef ikiwiSERVERIP
#define ikiwiSERVERIP                   /*RPM*/_D5BBFAE2_403B_43C6_A375_26FFC1E1F319
#endif

#ifndef ikiwichecktable
#define ikiwichecktable                 /*RPM*/_A0F3C6DD_8BC9_4B54_9AA4_B25B19617995
#endif

#ifndef ikiwivecAntiHook
#define ikiwivecAntiHook                /*RPM*/_E0BE822B_23E6_45DB_9371_8863EBA9C6C5
#endif

#ifndef KiwiDyldMacheaderInit
#define KiwiDyldMacheaderInit           /*RPM*/_090207C1_655A_4F86_85FA_C0F75E06151F
#endif

#ifndef KiwiDyldMacheaderExit
#define KiwiDyldMacheaderExit           /*RPM*/_BBEF2FB6_3187_4598_8CE1_031D2F510D83
#endif

#ifndef KiwiProcessCallbacks
#define KiwiProcessCallbacks            /*RPM*/_8DB6C700_B22F_424D_BC0B_855E0F9B05C3
#endif

#ifndef _KiwiEncodedString
#define _KiwiEncodedString              /*RPM*/_41B534ED_DA3A_4C70_872B_0EDA93880554
#endif

#ifndef KiwiEncodedString
#define KiwiEncodedString               /*RPM*/_E54FC1AA_EB43_47F2_870F_0419087657A7
#endif

#ifndef KiwiDecodeCString
#define KiwiDecodeCString               /*RPM*/_989D248F_92AB_4060_8AE9_C79D8F072C16
#endif

#ifndef KiwiDecodeOcString
#define KiwiDecodeOcString              /*RPM*/_178C3903_9C5F_4A8A_9BAC_2BCF86834F7F
#endif

#ifndef KiwiDecodeCStringXor
#define KiwiDecodeCStringXor            /*RPM*/_C6B30900_B649_4993_B68E_1C5D19BAAA70
#endif

#ifndef KiwiSecTransData
#define KiwiSecTransData                /*RPM*/_94828207_9102_49A7_985A_3B9007D0B4E3
#endif

#ifndef KiwiSecTransDataPayload
#define KiwiSecTransDataPayload         /*RPM*/_017FDA1C_B0BC_4724_842D_4529A4328732
#endif

#ifndef KiwiDeviceInfoType
#define KiwiDeviceInfoType              /*RPM*/_B7A3BAFE_8061_4C53_A51F_312C51DA3820
#endif

#ifndef KiwiSendSymbol
#define KiwiSendSymbol                  /*RPM*/_C1580F76_F294_4FC2_88E5_662C52B0A1D0
#endif

#ifndef KiwiSendDeviceInfo
#define KiwiSendDeviceInfo              /*RPM*/_139F999A_402B_4B49_B160_2F05CF1C476B
#endif

#ifndef KiwiDebugInfo
#define KiwiDebugInfo                   /*RPM*/_2C3A1459_2961_4C17_8A1C_F9A764E8A261
#endif

#ifndef KiwiHookInfoType
#define KiwiHookInfoType                /*RPM*/_3E295DD6_79E8_431D_A7B3_CAD0C005AC4A
#endif

#ifndef KiwiHookInfo
#define KiwiHookInfo                    /*RPM*/_14DEDD88_9C5D_4FDD_9F8F_FD37F354240E
#endif

#ifndef KiwiInjectInfo
#define KiwiInjectInfo                  /*RPM*/_B520735E_CE52_4686_BA44_199ED288B057
#endif

#ifndef KiwiJailbreakInfo
#define KiwiJailbreakInfo               /*RPM*/_8FD32657_1230_4191_8167_3432B965BB2F
#endif

#ifndef KiwiTamperInfo
#define KiwiTamperInfo                  /*RPM*/_1456A0EB_2418_4546_A0CF_A2693F0A3520
#endif

#ifndef KiwiVersion
#define KiwiVersion                     /*RPM*/_5D7E0AD4_3434_4815_807B_6665248488DD
#endif

#ifndef KiwiSendInfoMask
#define KiwiSendInfoMask                /*RPM*/_22786F6F_7568_4CD6_8255_039834755410
#endif

#ifndef KiwiSendInfo
#define KiwiSendInfo                    /*RPM*/_A31E7781_5E35_4555_8DD0_D30A5101A086
#endif

#ifndef KiwiSecTransAddInfoToSend
#define KiwiSecTransAddInfoToSend       /*RPM*/_B496A1B3_E9B1_4F20_82DF_D984EB0803E6
#endif

#ifndef KiwiSetServerPort
#define KiwiSetServerPort               /*RPM*/_EC6341B3_60FC_4EC6_A1E9_DEEFCFB39C16
#endif

#ifndef KiwiClientInit
#define KiwiClientInit                  /*RPM*/_BC3EFE5A_898C_485E_9C22_AF9CD4639A66
#endif

#ifndef KiwiClientExit
#define KiwiClientExit                  /*RPM*/_E3982726_F72F_4549_894E_9DA53418E837
#endif

#ifndef CKiwiMobileClient
#define CKiwiMobileClient               /*RPM*/_C5393E7B_2121_4B61_8F77_5C5558756834
#endif

#ifndef KiwiGetDeviceInfo
#define KiwiGetDeviceInfo               /*RPM*/_BFC6D139_9550_4A7C_B47C_604C19EFCF1B
#endif

#ifndef KiwiUploadAttackInfoDirect
#define KiwiUploadAttackInfoDirect      /*RPM*/_8BBC684D_15B3_45FE_AFA3_9F00B59B2CEB
#endif

#ifndef KiwiCompress
#define KiwiCompress                    /*RPM*/_8C16A290_5A12_44F5_87C1_CDB60ADCF884
#endif

#ifndef KiwiUncompress
#define KiwiUncompress                  /*RPM*/_FDBD96E8_A621_447C_94E7_51D822238BA5
#endif

#ifndef KiwiServerEncode
#define KiwiServerEncode                /*RPM*/_FD114A16_A919_4E8A_B8B6_0D9482A6F4D4
#endif

#ifndef KiwiServerDecode
#define KiwiServerDecode                /*RPM*/_32B1B36F_AFC4_4AF5_B31E_797C3EC2A9E8
#endif

#ifndef KiwiServerDecodeUserid
#define KiwiServerDecodeUserid          /*RPM*/_8A3A615E_41B7_4824_810A_858596E007FC
#endif

#ifndef KiwiDefaultCallback
#define KiwiDefaultCallback             /*RPM*/_14B46963_C290_496C_9418_835E4B310625
#endif

#ifndef sendToMobileServer
#define sendToMobileServer              /*RPM*/_8095C3B3_009F_4894_A4DB_ABB053B72A9B
#endif

#ifndef KiwiReadConfigFile
#define KiwiReadConfigFile              /*RPM*/_FDD72965_B0BA_40A0_8416_74B44719399A
#endif

#ifndef KiwiWriteConfigFile
#define KiwiWriteConfigFile             /*RPM*/_F406097C_FB71_4D8B_9856_A7E6B7E96A8F
#endif

#ifndef kiwi_get_ptrace
#define kiwi_get_ptrace                 /*RPM*/_F3295C3B_17C5_40C1_9128_E3CF055229DA
#endif

#ifndef kiwi_search_svc
#define kiwi_search_svc                 /*RPM*/_7A29A8D3_19BC_4202_A2DC_75AA35782C1E
#endif

#ifndef iKiwiCheckfuncName
#define iKiwiCheckfuncName              /*RPM*/_82047A91_CB56_432F_9290_BE189DEC26F9
#endif

#ifndef kiwi_search_opcode
#define kiwi_search_opcode              /*RPM*/_58C0FD5E_2BE6_419B_8480_B267F6836028
#endif

#ifndef kiwi_default_action
#define kiwi_default_action             /*RPM*/_4ED77F84_4576_48CB_8A28_8624D4795977
#endif

#ifndef KiwiUpdateVersion
#define KiwiUpdateVersion               /*RPM*/_6F3E16EF_C7A9_4068_90CA_7ADFFECAB0D2
#endif

#ifndef kiwi_should_exit_whole_process
#define kiwi_should_exit_whole_process  /*RPM*/_779F715E_CFBB_4412_B584_EB48D1C7B1B5
#endif

#ifndef kiwi_syscall_stub0
#define kiwi_syscall_stub0              /*RPM*/_5A1DC0F8_ABBD_4A13_A772_084CBE593926
#endif

#ifndef kiwi_syscall_stub1
#define kiwi_syscall_stub1              /*RPM*/_D8F84404_7A21_41A9_9992_8F659F573BB7
#endif

#ifndef KiwiCrashReport
#define KiwiCrashReport                 /*RPM*/_DE651F08_C5C1_4860_BF2C_07B6F684D478
#endif

#ifndef KiwiHookInfo
#define KiwiHookInfo                    /*RPM*/_443DFA02_BBBE_4718_BFAC_C597D56F4395
#endif

#ifndef CKiwiClient
#define CKiwiClient                     /*RPM*/_F6592154_0309_417F_8F1E_BDA4C2B053CB
#endif

#ifndef makeToSendInfoKiwiHookInfo
#define makeToSendInfoKiwiHookInfo      /*RPM*/_06486E07_C251_4828_8404_AF12472A1903
#endif

#ifndef KiwiSelectorFromString
#define KiwiSelectorFromString          /*RPM*/_A625B2C7_E559_42EC_80D9_70C2498874C3
#endif

#ifndef KiwiClassFromString
#define KiwiClassFromString             /*RPM*/_644D64A6_A00B_4FD5_AE47_205334B2D4AC
#endif

#ifndef KiwiProtocolFromString
#define KiwiProtocolFromString          /*RPM*/_997C91C3_BFAF_45F6_B3F6_E4851531DF95
#endif

#ifndef KiwiApplicationMain
#define KiwiApplicationMain             /*RPM*/_1B5F3FE3_255D_4CE8_B468_DA7276223571
#endif

#endif
