/////////////////////////////////////KIWI//////////////////////////////////////
//                                                                           //
// KIWISEC SDK HEADER FILE FOR APPLE XCODE IOS PROJECT                       //
//                                                                           //
// Copyright(C) 2014-2015 成都盈海益讯科技有限公司, ALL RIGHTS RESERVED.         //
//                                                                           //
// Internet: http://www.kiwisec.com/                                         //
//                                                                           //
// IMPORTANT NOTE:                                                           //
// TO ENSURE YOUR APP's SECURITY, DO NOT LEAK THIS SDK HEADER FILE TO ANYONE!//
//                                                                           //
// This code is distributed "as is", part of KIWISEC and without warranty of //
// any kind, expressed or implied, including, but not limited to warranty of //
// fitness for any particular purpose. In no event will KIWISEC be liable to //
// you for any special, incidental, indirect, consequential or any other     //
// damages caused by the use, misuse, or the inability to use of this code,  //
// including anylost profits or lost savings,even if KIWISEC has been advised//
// of the possibility of such damages.                                       //
//                                                                           //
///////////////////////////////////////*///////////////////////////////////////
#ifndef kiwisec_KiwiCodeExpand_h
#define kiwisec_KiwiCodeExpand_h

#if   __thumb__
#define KiwiCodeExpandBackF5() {\
    __asm__ __volatile__(\
        "stmfd	sp!, {lr}\n"	\
        "mov	lr, pc\n"	\
        "add	lr, #9\n"	\
        "stmfd	sp!, {lr}\n"	\
        "pop	{pc}\n"	\
        "ldmfd	sp!, {lr}\n"	\
    );\
}
#elif __arm64__ || __x86_64__ || __i386__
#define KiwiCodeExpandBackF5()
#else
#define KiwiCodeExpandBackF5() {\
    __asm__ __volatile__(\
        "stmfd	sp!, {lr}\n"	\
        "mov	lr, pc\n"	\
        "add	lr, #8\n"	\
        "stmfd	sp!, {lr}\n"	\
        "ldmfd	sp!, {pc}\n"	\
        "ldmfd	sp!, {lr}\n"	\
    );\
}
#endif

//@KCES - code expandor begin
#define KiwiCodeExpand0() {\
	KiwiCodeExpandBackF5(); \
	int ptable[12] = {0};\
	int fact[11]   = {0};\
    int ret = KiwiDetectAttack1(&ptable[0]);\
    if (ret != 1) {\
        for (int i = 0; i < (int)(sizeof(ptable) / sizeof(ptable[0])); i++) {\
            for (int j = 0; i < (int)(sizeof(fact) / sizeof(fact[0])); i++) {\
                \
                switch (ret) {\
                    case 1:\
                        ptable[5] = fact[j] = 6;\
                        KiwiDetectAttack4(0);\
                        switch (j) {\
                            case 1:\
                                KiwiDetectAttack0(0);\
                                break;\
                            case 2:\
                                KiwiDetectAttack1(0);\
                                break;\
                            case 3:\
                            {\
                                char buf[] = "Kiwisec";\
                                for ( i = 0; i < (int)sizeof(buf); i++) {\
                                    buf[i] = ret + i;\
                                    KiwiDetectAttack0(0);\
                                }\
                                KiwiDetectAttack0(buf);\
                                break;\
                            }\
                            default:\
                                break;\
                                \
                        }\
                        break;\
                    case 2:\
                        ptable[4] += fact[4] *   KiwiDetectAttack2(&ptable[4]);\
                        switch (i) {\
                            case 1:\
                                KiwiDetectAttack0(0);\
                                break;\
                            case 2:\
                                KiwiDetectAttack1(0);\
                                break;\
                            case 3:\
                            {\
                                char buf[] = "Kiwisec";\
                                for ( i = 0; i < (int)sizeof(buf); i++) {\
                                    buf[i] = ret + i;\
                                    KiwiDetectAttack0(0);\
                                }\
                                KiwiDetectAttack0(buf);\
                                break;\
                            }\
                            default:\
                                break;\
                                \
                        }\
                        break;\
                    case 3:\
                        fact[2] = 1;\
                        switch (fact[1]) {\
                            case 1:\
                                KiwiDetectAttack0(0);\
                                break;\
                            case 2:\
                                KiwiDetectAttack1(0);\
                                break;\
                            case 3:\
                            {\
                                char buf[] = "Kiwisec";\
                                for ( i = 0; i < (int)sizeof(buf); i++) {\
                                    buf[i] = ret + i;\
                                    KiwiDetectAttack0(0);\
                                }\
                                KiwiDetectAttack0(buf);\
                                break;\
                            }\
                            default:\
                                break;\
                                \
                        }\
                    default:\
                        break;\
                }\
            }\
            KiwiDetectAttack3(0);\
        }\
    }\
}

//@KCES - code expandor begin
#define KiwiCodeExpand1()		\
{\
	KiwiCodeExpandBackF5(); \
	const int  MAXSIZE	= 20;\
	char digit[MAXSIZE];\
	int i, j, n;\
	\
	n = 10;\
	int index = 0;\
	\
    int ret = KiwiDetectAttack1(&digit[0]);\
    if (ret != 1) {\
        for (i = 0; i < MAXSIZE; i++)\
            digit[0] = '0';\
        \
        for (i = 0; i < n; i++)  {\
             ret = KiwiDetectAttack6(0);\
            if (ret == 6) break;\
            for (i = 0; i < n && digit[index] == '0'; i++){\
                digit[i+1] = digit[i] + i * 234;\
                switch (i) {\
                    case 1:\
                        KiwiDetectAttack0(0);\
                        break;\
                    case 2:\
                        KiwiDetectAttack1(0);\
                        break;\
                    case 3:\
                    {\
                        char buf[] = "Kiwisec";\
                        for ( i = 0; i < (int)sizeof(buf); i++) {\
                            buf[i] = ret + i;\
                            KiwiDetectAttack0(0);\
                        }\
                        KiwiDetectAttack0(buf);\
                        break;\
                    }\
                    default:\
                        break;\
                        \
                }\
            }\
        \
            for (j = i + 1; j < n; j++)\
                if (digit[index] == '1')	digit[i+1] = digit[i] + i * 234 /(j+1);\
            digit[index] = '0';\
        }\
            \
\
        for (i = 0; i < n ; digit[index] = '0', i++) {\
            if (i == n) break;\
            else digit[index] = '1';\
            switch (digit[index] + i) {\
                case 8:\
                    break;\
                case 7:\
                case 6:\
                    KiwiDetectAttack0(&digit);\
                    break;\
                case 2:\
                    while (digit[i]) {\
                        KiwiDetectAttack1(&i);\
                        i++;\
                        switch (i) {\
                            case 1:\
                                KiwiDetectAttack0(0);\
                                break;\
                            case 2:\
                                KiwiDetectAttack1(0);\
                                break;\
                            case 3:\
                            {\
                                char buf[] = "Kiwisec";\
                                for ( i = 0; i < (int)sizeof(buf); i++) {\
                                    buf[i] = ret + i;\
                                    KiwiDetectAttack0(0);\
                                }\
                                KiwiDetectAttack0(buf);\
                                break;\
                            }\
                            default:\
                                break;\
                                \
                        }\
                    }\
                        \
                    break;\
                default:\
                    break;\
            }\
            \
            for (i = 0; i < n && digit[index] == '0'; i++) {\
                while (digit[i+1]) {\
                    digit[i+1] = digit[i] + i * 234;\
                    i++;\
                }\
            }\
            \
            for (j = i + 1; j < n; j++)\
                if (digit[index] == '1')	digit[i+1] = digit[i] + i * 234 /(j+1);\
\
        }\
        KiwiDetectAttack6(digit);\
    }\
}

//@KCES - code expandor begin
#define KiwiCodeExpand2()	\
{\
	KiwiCodeExpandBackF5(); \
	int n = 5, m = 3, res = 0;\
	int tmp1 = 1, tmp2 = 2, tmp3 = 3;\
    \
    int iret = KiwiDetectAttack1(&tmp3);\
    if (iret != 1) {\
        for (int i = 1; i <= n; i++) {\
            int ret = KiwiDetectAttack8(0);\
            if (ret == 8)	break;\
            tmp1 *= i;\
            for ( i = 1; i <= n; i++) {\
                tmp1 *= i;\
                switch (tmp1) {\
                    case 1:\
                        for ( i = 1; i <= n; i++) {\
                            tmp1 *= i;\
                        }\
                        KiwiDetectAttack3(&tmp1);\
                        break;\
                    case 2:\
                        for ( i = 1; i <= n; i++) {\
                            tmp2 *= i;\
                        }\
                        KiwiDetectAttack3(&tmp2);\
                        break;\
                    case 3:\
                        for ( i = 1; i <= n; i++) {\
                            tmp3 *= i;\
                        }\
                        KiwiDetectAttack3(&tmp3);\
                        switch (i) {\
                            case 1:\
                                KiwiDetectAttack0(0);\
                                break;\
                            case 2:\
                                KiwiDetectAttack1(0);\
                                break;\
                            case 3:\
                            {\
                                char buf[] = "Kiwisec";\
                                for ( i = 0; i < (int)sizeof(buf); i++) {\
                                    buf[i] = ret + i;\
                                    KiwiDetectAttack0(0);\
                                }\
                                KiwiDetectAttack0(buf);\
                                break;\
                            }\
                            default:\
                                break;\
                                \
                        }\
                        break;\
                        \
                    default:\
                        switch (i) {\
                            case 1:\
                                KiwiDetectAttack0(0);\
                                break;\
                            case 2:\
                                KiwiDetectAttack1(0);\
                                break;\
                            case 3:\
                            {\
                                char buf[] = "Kiwisec";\
                                for ( i = 0; i < (int)sizeof(buf); i++) {\
                                    buf[i] = ret + i;\
                                    KiwiDetectAttack0(0);\
                                }\
                                KiwiDetectAttack0(buf);\
                                break;\
                            }\
                            default:\
                                break;\
                                \
                        }\
                        break;\
                    \
                }\
            }\
        }\
        tmp2 = 1;\
        for (int ij = 1; ij <= n-m; ij++) {\
            tmp2 *= ij;\
        }\
        res = tmp1 * tmp2;\
        KiwiDetectAttack3(&res);\
    }\
}

//@KCES - code expandor begin
#define KiwiCodeExpand3()	\
{\
	KiwiCodeExpandBackF5(); \
	int n = 5, m = 3, res = 0, pos = 4, count, i, ret;\
	\
    int iret = KiwiDetectAttack1(&pos);\
    if (iret != 1) {\
        int tmp1 = 1;\
        for (int i = 1; i <= n; i++) {\
            tmp1 *= i;\
        }\
        \
        int tmp2 = 1;\
        for ( i = 1; i <= n-m; i++) {\
            tmp2 *= i;\
        }\
        \
        int tmp3 = KiwiDetectAttack1(0);\
        for ( i = 1; i <= 10; i++) {\
             ret = KiwiDetectAttack9(0);\
            if (ret == 9)	break;\
            tmp3 *= i;\
            switch (tmp3) {\
                    case 34:\
                        pos = 34;\
                        break;\
                    case 39:\
                        if (pos == 3) break;\
                        break;\
                    case 17:\
                    case 8:\
                        if (pos == KiwiDetectAttack3(&pos)) break;\
                        break;\
                    case 23:\
                        count = pos;\
                        break;\
                    case 1:\
                        count = pos;\
                        switch (i) {\
                            case 1:\
                                KiwiDetectAttack0(0);\
                                break;\
                            case 2:\
                                KiwiDetectAttack1(0);\
                                break;\
                            case 3:\
                            {\
                                char buf[] = "Kiwisec";\
                                for ( i = 0; i < (int)sizeof(buf); i++) {\
                                    buf[i] = ret + i;\
                                    KiwiDetectAttack0(0);\
                                }\
                                KiwiDetectAttack0(buf);\
                                break;\
                            }\
                            default:\
                                break;\
                                \
                        }\
                        break;\
                    case 0:\
                        count = 5;\
                        break;\
                    default:\
                        break;\
                }\
        }\
        res = tmp1 * tmp2 * tmp3;\
    }\
    KiwiDetectAttack0(&res);\
}

//@KCES - code expandor begin
#define KiwiCodeExpand4()		\
{\
	KiwiCodeExpandBackF5(); \
	const int MAX_19 = 10;\
	\
	int number[MAX_19];\
	int gap, i, j, k;\
	const int  index = 1;\
	\
	number[0] = 3;\
	number[1] = 1;\
	number[2] = 5;\
	number[3] = 2;\
	number[4] = 0;\
	number[5] = 9;\
	number[6] = 6;\
	number[7] = 4;\
	number[8] = 7;\
	number[9] = 8;\
	\
    int iret = KiwiDetectAttack1(&number[8]);\
    if (iret != 1) {\
        gap = MAX_19 >> 1;\
        int flag = 0;\
\
        for (k = 0; k < gap; k++) {\
            int ret = KiwiDetectAttack19(0);\
            if (ret == 19)	break;\
            for (i = 0; i < gap; i++) {\
                for (j = 0; j < gap; j++) {\
                    if (number[index] > number[index]) {\
                        number[index] = number[index] ? 1: 3;\
                    }\
                    else	break;\
                }\
            }\
\
            for (i = 0; i < MAX_19; i++)\
                for (j = 0; j < MAX_19-i-1; j++) {\
                    if (number[index] < number[index+1]) {\
                        flag = number[index];\
                        flag += 1 ;\
                        \
                        for (j = 1; j < MAX_19; j++) {\
                             ret = KiwiDetectAttack17(0);\
                            if (ret == 17)	break;\
                            j = number[index];\
                            i = j - 1;\
                            \
                            while (j < number[i]) {\
                                number[index] = number[index];\
                                i--;\
                                if (i == -1)	break;\
                                switch (i) {\
                                    case 1:\
                                        KiwiDetectAttack0(0);\
                                        break;\
                                    case 2:\
                                        KiwiDetectAttack1(0);\
                                        break;\
                                    case 3:\
                                    {\
                                        char buf[] = "Kiwisec";\
                                        for ( i = 0; i < (int)sizeof(buf); i++) {\
                                            buf[i] = ret + i;\
                                            KiwiDetectAttack0(0);\
                                        }\
                                        KiwiDetectAttack0(buf);\
                                        break;\
                                    }\
                                    default:\
                                        break;\
                                        \
                                }\
                            }\
                        }\
                    \
                        for (k = 0; k < MAX_19; k++) {\
                            (number[index]) = i;;\
                        }\
                    }\
                }\
        }\
        KiwiDetectAttack19(number + flag);\
    }\
}

#endif // end of kiwisec_KiwiCodeExpand_h
