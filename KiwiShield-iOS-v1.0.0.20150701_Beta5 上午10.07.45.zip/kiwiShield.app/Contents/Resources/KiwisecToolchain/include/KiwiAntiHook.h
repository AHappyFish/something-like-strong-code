/////////////////////////////////////KIWISEC///////////////////////////////////
//                                                                           //
// KIWISEC SDK HEADER FILE FOR APPLE XCODE IOS PROJECT                       //
//                                                                           //
// Copyright(C) 2014-2015 成都盈海益讯科技有限公司, ALL RIGHTS RESERVED.         //
//                                                                           //
// Internet: http://www.kiwisec.com/                                         //
//                                                                           //
// IMPORTANT NOTE:                                                           //
// TO ENSURE YOUR APP's SECURITY, DO NOT LEAK THIS SDK HEADER FILE TO ANYONE!//
//                                                                           //
// This code is distributed "as is", part of KIWISEC and without warranty of //
// any kind, expressed or implied, including, but not limited to warranty of //
// fitness for any particular purpose. In no event will KIWISEC be liable to //
// you for any special, incidental, indirect, consequential or any other     //
// damages caused by the use, misuse, or the inability to use of this code,  //
// including anylost profits or lost savings,even if KIWISEC has been advised//
// of the possibility of such damages.                                       //
//                                                                           //
///////////////////////////////////////*///////////////////////////////////////

#ifndef kiwisec_KiwiAntiHook_h
#define kiwisec_KiwiAntiHook_h

#include "KiwiBase.h"
#include "KiwiError.h"
#include "iKiwiRandomName.h"

#define ARM_CHECK_LEN   8
#define THUMB_CHECK_LEN 8

enum kiwi_hook_type
{
    INLINE_TYPE,        //native 函数的inline hook 和 fish hook 检测
    PTR_TYPE,           //针对指定函数地址做检测
    OC_TYPE,            //oc    函数的hook
    ERRO_TYPE
};

#ifdef __cplusplus
extern "C" {
#endif // end of __cplusplus
    
    /*
     @name：KiwiCheckHooker
     @func：检测是否被拦截
     @var0：hooked－1表示被拦截，0表示未被拦截
     */
    __KIWI_API_STATIC__
    enum KiwiErrorCode KiwiCheckHooker(KiwiBool *hooked);
    
    /*
     @name：AddCheckedFunctionForOc
     @func：添加OC类型的被检测函数
     @var0：cls－类
     @var1: sel－方法@selet
     */
    enum KiwiErrorCode AddCheckedFunctionForOc(const void *cls,const void *sel);
    
    /*
     @name：AddCheckedFunctionForIat
     @func：添加导入表和inilne hook类型的被检测函数
     @var0: strMethodName－方法名
     */
    enum KiwiErrorCode AddCheckedFunctionForIat(const char* strMethodName);
    
    /*
     @name：AddCheckedFunctionByPtr
     @func：添加被检测的函数
     @var0：ptrFunc－函数地址
     @var1：info－函数描述
     */
    enum KiwiErrorCode AddCheckedFunctionByPtr(void *ptrFunc, const char *info);
    
    
    /*
     @name：DeletCheckedFunctionByPtr
     @func：删除被检测的函数
     @var0：ptrFunc－函数地址
     */
    enum KiwiErrorCode DeletCheckedFunctionByPtr(void *ptrFunc);
    
    /*
     @name：DeletCheckedFunctionForIat
     @func：删除被检测的函数
     @var0：cls－类
     @var1: sel－方法@selet
     */
    enum KiwiErrorCode DeletCheckedFunctionForOc(const void *cls,const void *sel);
    
    /*
     @name：DeletCheckedFunctionForIat
     @func：删除被检测的函数
     @var0: strMethodName－方法名
     */
    enum KiwiErrorCode DeletCheckedFunctionForIat(const char* strMethodName);
    
#ifdef __cplusplus
}
#endif // end of __cplusplus
        
#endif
