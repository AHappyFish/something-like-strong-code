/////////////////////////////////////KIWISEC///////////////////////////////////
//                                                                           //
// KIWISEC SDK HEADER FILE FOR APPLE XCODE IOS PROJECT                       //
//                                                                           //
// Copyright(C) 2014-2015 成都盈海益讯科技有限公司, ALL RIGHTS RESERVED.         //
//                                                                           //
// Internet: http://www.kiwisec.com/                                         //
//                                                                           //
// IMPORTANT NOTE:                                                           //
// TO ENSURE YOUR APP's SECURITY, DO NOT LEAK THIS SDK HEADER FILE TO ANYONE!//
//                                                                           //
// This code is distributed "as is", part of KIWISEC and without warranty of //
// any kind, expressed or implied, including, but not limited to warranty of //
// fitness for any particular purpose. In no event will KIWISEC be liable to //
// you for any special, incidental, indirect, consequential or any other     //
// damages caused by the use, misuse, or the inability to use of this code,  //
// including anylost profits or lost savings,even if KIWISEC has been advised//
// of the possibility of such damages.                                       //
//                                                                           //
///////////////////////////////////////*///////////////////////////////////////

#ifndef kiwisec_KiwiBase_h
#define kiwisec_KiwiBase_h

//remember to rename makefile
///////////////////////////////////////*///////////////////////////////////////
#define __KIWI_SEC_PROFESSIONAL__ 0
#define __KIWI_SEC_IS_RELEASE__   1
///////////////////////////////////////*///////////////////////////////////////

#if __KIWI_SEC_PROFESSIONAL__
#define __KIWI_SEC_STANDARD__     0
#else
#define __KIWI_SEC_STANDARD__     1
#endif

#if __KIWI_SEC_PROFESSIONAL__
#define __KIWI_HAVE_DEBUG_INFO__  0
#elif __KIWI_SEC_IS_RELEASE__
#define __KIWI_HAVE_DEBUG_INFO__  0
#else
#define __KIWI_HAVE_DEBUG_INFO__  1
#endif

#define __KIWI_API_EXPORT__       __attribute__((visibility("default")))

#if __KIWI_SEC_IS_RELEASE__
    #define __KIWI_API_STATIC__   __attribute__((visibility("hidden")))
#else
    #define __KIWI_API_STATIC__   __KIWI_API_EXPORT__
#endif

#define __KIWI_API_INLINE__

#define __KIWI_CONSTRUCTOR__  __attribute__((visibility("hidden"), constructor))
#define __KIWI_DESTRUCTOR__   __attribute__((visibility("hidden"), destructor))

#define __KIWI_NAKED__        __attribute__((naked))
#define __ASM__               __asm__ __volatile__

//Callback declaration

#ifdef __cplusplus

#define __KIWICALLBACK_DECL__(_name) extern "C" void _name(int reserved)

#else

#define __KIWICALLBACK_DECL__(_name) void _name(int reserved)

#endif // end of __cplusplus
        
//Use these macros to define your own callbacks
#define __KIWICALLBACK_DECL_DEBUG__(_name)      __KIWICALLBACK_DECL__(_name)
#define __KIWICALLBACK_DECL_HOOK__(_name)       __KIWICALLBACK_DECL__(_name)
#define __KIWICALLBACK_DECL_INJECT__(_name)     __KIWICALLBACK_DECL__(_name)
#define __KIWICALLBACK_DECL_JAILBREAK__(_name)  __KIWICALLBACK_DECL__(_name)
#define __KIWICALLBACK_DECL_TAMPER__(_name)     __KIWICALLBACK_DECL__(_name)

#include <stdlib.h>

typedef int KiwiBool;

#endif
